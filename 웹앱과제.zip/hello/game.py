from flask import Flask, request, render_template, redirect, url_for, abort
app = Flask(__name__)


@app.route('/') 
def index(): 
    return render_template('index.html')

@app.route('/index.html') 
def index2(): 
    return render_template('index.html')


@app.route('/join.html') 
def join(): 
    return render_template('join.html')



@app.route('/login.html') 
def login(): 
    return render_template('login.html')

@app.route('/game.html') 
def game(): 
    return render_template('game.html')

@app.route('/explain.html') 
def explain(): 
    return render_template('explain.html')



if __name__ == '__main__':
    app.run(debug=True)